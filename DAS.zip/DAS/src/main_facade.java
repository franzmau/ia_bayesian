
public class main_facade {
	public static void main(String[] args) {
		 PersonMaker personMaker = new PersonMaker();
		 personMaker.payEmployee(3000);
		 personMaker.payEntreperneur(2000,3);
		 personMaker.payfreelance(4500);
	}
}
