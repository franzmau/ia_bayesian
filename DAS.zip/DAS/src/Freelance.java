
public class Freelance implements Person {

	public void income(int i) {
		// TODO Auto-generated method stub
		System.out.println("You will earn "+(i*5/7*2)+" of dlls per month \n");
	}

	public void income(int i, int j) {
		// TODO Auto-generated method stub
		income(i);
	}

}
