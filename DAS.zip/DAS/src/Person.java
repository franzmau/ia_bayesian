public interface Person {
   void income(int i);

void income(int i, int j);

}

