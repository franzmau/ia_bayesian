import java.util.ArrayList;
import java.util.Stack;




public class main {
	
	
	

		

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		main m = new main();
		
//	Node n= new Node (.4,);
		

		
	}

}