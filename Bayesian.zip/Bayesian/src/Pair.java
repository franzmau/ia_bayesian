
public class Pair {
	
	public int from;
	public int to;
	
	public Pair(int from, int to){
		this.from = from;
		this.to = to;
	}

}